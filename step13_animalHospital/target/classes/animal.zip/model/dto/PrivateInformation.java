package animal.model.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PrivateInformation {
	
	/** �������� ����**/
	private Pet Pet;
	
	/** ��ȣ�� ���� ���� **/
	private Protector Protector;
	
	public PrivateInformation() {}
	public PrivateInformation(Pet Pet, Protector Protector) {
		this.Pet = Pet;
		this.Protector = Protector;
		}
	
	public Pet getPet() {
		return Pet;
	}
	public Protector getProtector() {
		return Protector;
	}
	
}
