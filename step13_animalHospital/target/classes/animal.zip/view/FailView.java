package animal.view;

public class FailView {

	public static void failMessageView(String message) {
		System.out.println("�߻��� ���ܻ�Ȳ : " + message);
	}
}
